import './App.css'

function App() {

  return (
    <>
      <h1>Video Voice Translator</h1>
    </>
  )
}

export default App